import { AppShell } from "@/components/AppShell";
import { novos, reformados, usados, terceiros, TireRow } from "@/lib/mockData";

function Block({number,title,color,rows,type}:{number:number;title:string;color:string;rows:TireRow[];type:"novo"|"reformado"|"usado"|"terceiro"}){
  const headers = type === "novo"
    ? ["Cód do material","Descrição do material","Nº a fogo","DOT","Medida","Marca","Modelo","Qtd. vidas","MM original","Data entrada estoque","Valor compra","KM rodado","Status"]
    : type === "reformado"
    ? ["Cód do material","Descrição do material","Nº a fogo","DOT","Medida","Marca","Modelo","Qtd. vidas","MM da banda","Data última reforma","Valor reforma","Último reformador","Status"]
    : type === "usado"
    ? ["Cód do material","Descrição do material","Nº a fogo","DOT","Medida","Marca","Modelo","Qtd. vidas","MM atual","KM rodado atual","Valor proporcional","Status"]
    : ["Selecionar","Cód do material","Descrição do material","Nº a fogo","DOT","Medida","Marca","Modelo","Qtd. vidas","MM atual","KM rodado atual","Valor proporcional","Data envio reforma","Prestador","Status"];
  return <section className="section">
    <div className="sectionHead"><div className="sectionTitle"><span className="badgeNum" style={{background:color}}>{number}</span><span style={{color}}>{title}</span></div><div className="actions">{type==="terceiro"&&<button className="btn purple">Ações do pneu selecionado</button>}<button className="btn">Ações</button></div></div>
    <div className="tableWrap"><table className="table"><thead><tr>{headers.map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>
      {rows.map(r=><tr key={r.fogo}>
        {type==="terceiro"&&<td><input type="checkbox" aria-label={`Selecionar ${r.fogo}`}/></td>}
        <td>{r.material}</td><td>{r.descricao}</td><td>{r.fogo}</td><td>{r.dot}</td><td>{r.medida}</td><td>{r.marca}</td><td>{r.modelo}</td><td>{r.vidas}</td><td>{r.mm}</td>
        {type==="novo"&&<><td>{r.data}</td><td>{r.valor}</td><td>{r.km}</td><td className="status ok">Disponível no Estoque</td></>}
        {type==="reformado"&&<><td>{r.data}</td><td>{r.valor}</td><td>{r.extra}</td><td className="status ok">Disponível no Estoque</td></>}
        {type==="usado"&&<><td>{r.km}</td><td>{r.valor}</td><td className="status ok">Disponível no Estoque</td></>}
        {type==="terceiro"&&<><td>{r.km}</td><td>{r.valor}</td><td>{r.data}</td><td>{r.extra}</td><td className="status blocked">Indisponível para montagem</td></>}
      </tr>)}
    </tbody></table></div>
  </section>
}

export default function EstoquePage(){
  return <AppShell active="/estoque"><div className="content">
    <div className="toolbar"><div><h2>Estoque de pneus</h2><p>Consulte e gerencie o estoque da unidade selecionada.</p></div><div className="selectWrap"><label>Unidade (estoque atual)</label><select defaultValue="matriz"><option value="matriz">Usina Betmix Matriz</option><option>Filial 02</option><option>Filial 03</option></select></div></div>
    <div className="kpis">
      <div className="kpi blue"><small>Pneus novos</small><b>28 un.</b><span>R$ 336.000,00</span></div>
      <div className="kpi green"><small>Pneus reformados</small><b>16 un.</b><span>R$ 168.000,00</span></div>
      <div className="kpi orange"><small>Pneus usados</small><b>42 un.</b><span>MM médio: 10,2 mm · R$ 84.500,00</span></div>
      <div className="kpi purple"><small>Enviados para reforma</small><b>26 un.</b><span>Reformadora Sul 12 · VIPAL 8 · Rodoband 6</span></div>
    </div>
    <Block number={1} title="Bloco 1 - Pneus novos" color="#0d61d8" rows={novos} type="novo"/>
    <Block number={2} title="Bloco 2 - Pneus reformados" color="#149447" rows={reformados} type="reformado"/>
    <Block number={3} title="Bloco 3 - Pneus usados" color="#ef8b00" rows={usados} type="usado"/>
    <Block number={4} title="Bloco 4 - Pneus em processo de reforma (em terceiros)" color="#6b4bd2" rows={terceiros} type="terceiro"/>
    <div className="note">Os valores proporcionais serão calculados com base no histórico de investimentos e KM rodado acumulado de cada pneu.</div>
  </div></AppShell>
}
