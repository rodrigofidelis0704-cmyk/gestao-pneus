import Link from "next/link";
import { AppShell } from "@/components/AppShell";

const pillars = [
  ["Estoque de pneus", "Consulte e gerencie pneus novos, reformados, usados e em terceiros.", "/estoque"],
  ["Gestão de pneus aplicados", "Visualize os pneus montados por equipamento e posição.", "/aplicados"],
  ["Pneus sucateados", "Controle descarte, motivo de sucata, vida total e CPK final.", "/sucata"],
  ["Serviços em pneus", "Registre inspeções, calibragem, rodízio, reparos e trocas.", "/servicos"]
];

export default function Home() {
  return <AppShell active="/">
    <div className="content">
      <section className="hero"><div><h2>Bem-vindo à Gestão de Pneus Betmix</h2><p>Selecione um dos quatro pilares para começar.</p></div></section>
      <div className="cards">
        {pillars.map(([title, text, href]) => <div className="card" key={title}><h3>{title}</h3><p>{text}</p><Link className="cta" href={href}>Acessar</Link></div>)}
      </div>
    </div>
  </AppShell>;
}
