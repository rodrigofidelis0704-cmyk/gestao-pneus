"use client";
import { useState } from "react";
import { AppShell } from "@/components/AppShell";

export default function ServicosPage(){
  const [found,setFound]=useState(false);
  return <AppShell active="/servicos"><div className="content">
    <section className="hero"><div><h2>Serviços em pneus</h2><p>Identifique o equipamento e confirme o KM atual antes de iniciar os lançamentos.</p></div></section>
    <div style={{height:18}}/>
    <div className="searchPanel">
      <div className="searchBox"><h3>Buscar por placa</h3><input placeholder="Ex.: ABC1D23"/><button onClick={()=>setFound(true)}>Pesquisar por placa</button>{found&&<div className="kmBox"><label>KM atual do equipamento</label><input type="number" placeholder="Ex.: 185140"/><small>Último registro: 184.520 km</small></div>}</div>
      <div className="searchBox"><h3>Buscar por ID da frota</h3><input placeholder="Ex.: BT1023"/><button onClick={()=>setFound(true)}>Pesquisar por ID</button>{found&&<div className="kmBox"><label>KM atual do equipamento</label><input type="number" placeholder="Ex.: 185140"/><small>Confirme o KM para abrir a sessão de serviços.</small></div>}</div>
    </div>
    {found&&<div className="note">Equipamento localizado. Após confirmar o KM atual, o sistema abrirá o painel com todos os pneus aplicados, pendências e atalhos de serviço.</div>}
  </div></AppShell>
}
