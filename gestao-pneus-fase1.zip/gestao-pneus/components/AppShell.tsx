import Link from "next/link";

const items = [
  ["/", "Início"],
  ["/frota", "Frota"],
  ["/relatorios", "Relatórios"],
  ["/estoque", "Estoque de pneus"],
  ["/aplicados", "Gestão de pneus aplicados"],
  ["/sucata", "Pneus sucateados"],
  ["/servicos", "Serviços em pneus"],
  ["/configuracoes", "Configurações"]
];

export function AppShell({ children, active = "" }: { children: React.ReactNode; active?: string }) {
  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brandMark">B</div>
          <div className="brandText"><strong>BETMIX</strong><span>CONCRETO</span></div>
        </div>
        <nav className="nav">
          {items.map(([href, label]) => (
            <Link key={href} href={href} className={active === href ? "active" : ""}>{label}</Link>
          ))}
        </nav>
      </aside>
      <main className="main">
        <header className="topbar">
          <div className="title"><h1>Gestão de Pneus Betmix</h1><p>Gerencie o estoque e os pneus aplicados da sua frota.</p></div>
          <div className="user"><div className="avatar">U</div><strong>Olá, Usuário</strong></div>
        </header>
        {children}
      </main>
    </div>
  );
}
