# Gestão de Pneus Betmix

Starter web do sistema de gestão de pneus definido neste projeto.

## Stack
- Next.js + TypeScript
- PostgreSQL
- Prisma ORM
- CSS responsivo sem dependência de framework visual

## Primeira execução
1. Instale Node.js LTS.
2. Copie `.env.example` para `.env` e informe a `DATABASE_URL` do PostgreSQL.
3. Rode `npm install`.
4. Rode `npm run prisma:generate`.
5. Rode `npm run prisma:migrate -- --name initial`.
6. Rode `npm run prisma:seed`.
7. Rode `npm run dev`.
8. Acesse `http://localhost:3000`.

## Telas já iniciadas
- Início com os quatro pilares.
- Estoque de pneus com KPIs e quatro blocos.
- Serviços em pneus com busca por placa/ID e KM atual obrigatório.

## Próximas etapas
- Autenticação e perfis.
- Integração real do estoque com PostgreSQL.
- Painel de pneus aplicados por frota/layout.
- Modais de inspeção, calibragem, rodízio, troca e reparo.
- Fluxos de reforma, sucata, fotos e auditoria.
- Deploy Vercel + Supabase/Neon.
